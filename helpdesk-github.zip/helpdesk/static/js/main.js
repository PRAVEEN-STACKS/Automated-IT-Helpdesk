// Auto-dismiss flash messages after 5s
document.addEventListener("DOMContentLoaded", () => {
  const flashes = document.querySelectorAll(".flash");
  flashes.forEach(f => {
    setTimeout(() => {
      f.style.transition = "opacity .5s";
      f.style.opacity = "0";
      setTimeout(() => f.remove(), 500);
    }, 5000);
  });
});
